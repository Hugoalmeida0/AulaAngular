export class ItemLista {
    id?: number;
    nome?: string;
    comprado: boolean = false;
}