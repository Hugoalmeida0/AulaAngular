import { Component } from '@angular/core';

@Component({
  selector: 'app-minhapagina',
  imports: [],
  templateUrl: './minhapagina.component.html',
  styleUrl: './minhapagina.component.scss'
})
export class MinhapaginaComponent {

}
