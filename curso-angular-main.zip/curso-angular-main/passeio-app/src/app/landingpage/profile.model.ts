export interface Profile {
    email: string;
    name: string;
}