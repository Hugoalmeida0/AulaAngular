export interface LayoutProps {
    titulo: string;
    subTitulo: string;
}